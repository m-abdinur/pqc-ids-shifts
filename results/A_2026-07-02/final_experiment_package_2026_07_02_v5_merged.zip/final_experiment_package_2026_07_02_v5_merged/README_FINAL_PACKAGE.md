# final_experiment_package_2026_07_02_v5_merged

This is the merged final experiment package for the dissertation experiment.

## What this package contains

This package combines:

1. The full v3 experiment-results package:
   `/content/drive/MyDrive/pqc_ids_dissertation/final_experiment_package_2026_06_24_v3`

2. The verified v4 data-provenance folder:
   `/content/drive/MyDrive/final_experiment_package_2026_06_24_v4.zip`

## Main folders

- `00_data_provenance/` — data-preparation manifest, raw CSV checksums, final class distribution, and final feature list.
- `01_raw_results/` — raw experiment result files.
- `02_analysis_tables/` — analysis-ready Chapter 4 tables and statistical outputs.
- `03_figures/` — generated result figures.
- `04_code/` — experiment and analysis scripts.
- `05_environment/` — software environment records.
- `06_notes/` — package notes and objective-to-evidence mapping.

## Provenance zip verification

The v4 provenance zip SHA-256 is:

`a4ad7524e000b4f8d557b9521a3fd2d5f8505c002364675892d86055743ffb6a`

## Manifest

The final per-file SHA-256 manifest for this merged package is:

`final_experiment_package_2026_07_02_v5_merged_file_manifest.csv`

Use that v5 manifest for final thesis appendix reporting.

## Important note

The previous v4 zip was not the full experiment package. It contained only `00_data_provenance/`.
This v5 package is the merged package intended for final reproducibility.
