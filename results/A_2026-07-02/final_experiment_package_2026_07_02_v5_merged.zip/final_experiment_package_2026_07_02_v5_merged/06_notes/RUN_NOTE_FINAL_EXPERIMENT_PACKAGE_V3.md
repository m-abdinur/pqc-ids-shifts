# Final Experiment Package v3

This package repairs the v2 evidence bundle and adds the C4 cross-footprint extraction, R_oracle retraining baseline, and R_oracle formal statistical add-on.

v2 already added:
- ROC-AUC tables for the main revised and B3 identifier-free settings.
- An ablation table with 95% confidence-interval half-widths.
- An improved ablation figure that includes both C3 true and C3 random.

v3 restores:
- The revised statistical analysis pack.
- The Python environment note.
- The objective-to-evidence map.

v3 also adds:
- C4 cross-footprint transfer tables for weighted F1 and ROC-AUC.
- A C4 cross-footprint weighted F1 figure.
- R_oracle raw and summary outputs.
- An R_oracle main table and weighted F1 figure.
- The R_oracle script used for the retraining baseline.
- An R_oracle formal statistical add-on with paired tests, Wilcoxon tests, effect sizes, and Holm-adjusted TOST equivalence tests.

The C4 files were extracted from results already present in revised_pipeline_raw.json. No model training was rerun for the C4 extraction.

The R_oracle baseline was run separately. It trains on the approximated shifted training representation and tests on the approximated shifted test representation using all 70 features. It is an oracle retraining baseline, not the proposed mitigation, because it assumes labelled shifted training data are available.

The R_oracle statistical add-on uses the already-generated R_oracle outputs. No model training was rerun for this analysis. It formally tests C2 vs R_oracle, C3 vs R_oracle, and C1 vs R_oracle using paired tests and TOST equivalence with a ±0.01 margin.

Main interpretation:
- C2 shows degradation under the approximated ML-KEM-768 feature shift.
- C3 returns close to the C1 baseline in the main setting.
- B3 shows that RF and XGBoost recover without identifier-like features, while MLP only partially recovers.
- Ablation shows that length-statistical features drive most of the degradation.
- C3 random does not recover, which supports targeted stable-feature selection rather than generic feature reduction.
- C4 is a footprint-sensitivity check. Its main value is showing how C2 changes across already-computed footprint settings. C3 stability is expected because C3 removes the shifted feature families.
- R_oracle shows that retraining on labelled shifted data can largely recover performance, but it relies on stronger assumptions than C3.
- The R_oracle formal analysis shows that C3 is practically equivalent to R_oracle within the predefined ±0.01 margin for weighted F1 across all three classifiers.
- The study is a feature-level approximation, not a validation on real deployed ML-KEM TLS packet captures.
