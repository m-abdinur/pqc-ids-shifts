# R_oracle formal statistical add-on

This analysis uses the already-generated R_oracle results. No model training is rerun.

Equivalence margin: ±0.01

## Main reading

- C2 vs R_oracle tests whether oracle retraining recovers the degradation seen under the shifted-test condition.
- C3 vs R_oracle tests whether the stable-feature pipeline is practically equivalent to oracle retraining.
- C1 vs R_oracle checks whether oracle retraining returns close to the original baseline.

## Weighted F1: C3 vs R_oracle

- Random Forest: mean difference 0.0019, 95% CI 0.0019 [0.0011, 0.0026], Holm-adjusted TOST p=7.848e-09; equivalent.
- XGBoost: mean difference -0.0008, 95% CI -0.0008 [-0.0017, 0.0001], Holm-adjusted TOST p=1.395e-08; equivalent.
- MLP: mean difference -0.0013, 95% CI -0.0013 [-0.0051, 0.0025], Holm-adjusted TOST p=0.001924; equivalent.

## Weighted F1: C2 vs R_oracle

- Random Forest: C2 mean 0.7344, R_oracle mean 0.8486, mean difference -0.1142, paired t p=7.578e-05.
- XGBoost: C2 mean 0.7691, R_oracle mean 0.8598, mean difference -0.0907, paired t p=2.31e-13.
- MLP: C2 mean 0.5923, R_oracle mean 0.8428, mean difference -0.2505, paired t p=1.635e-12.